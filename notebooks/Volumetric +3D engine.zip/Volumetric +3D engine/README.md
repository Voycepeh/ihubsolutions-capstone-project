# Carton Selection Engine (Capstone 1.6 – 1.9)

Chooses the cartons for an order: which SKUs go together, which carton size is used, and how many cartons the order needs.
The goal is the **fewest cartons**, then the **smallest cartons**, while respecting weight, orientation rules and a user-defined fill cap.

The solver is a two-stage pipeline:

1. **Volumetric planner (stage 1)** – a cheap volume/weight/fill-cap pass. It decides whether the order fits one carton or must be split, and assigns a best-fit carton to each group of items.
2. **3D Extreme Point engine (stage 2)** – the exact geometric check. Volume is a *necessary* condition, not a *sufficient* one, so each planned group is verified in 3D (coordinates, rotation, height, weight). Groups that fail are moved to a larger carton or split, and the leftovers are re-planned.

Everything runs **per order**: one order = one customer, and items from different orders are never combined.

---

## Pipeline

```
items of ONE order
   │
   ├─ pre-screen: drop items that cannot fit any empty carton (size / rotation / weight)  → "unpackable"
   │
   └─ repeat until the pool is empty
        plan  = volumetric_planner(pool)           # batches + best-fit carton, fill cap applied
        for each batch:
            try cartons from the ASSIGNED one upward (smaller ones already failed volume/cap)
              - first carton where the whole batch packs in 3D → commit it
            if no carton holds the whole batch (forced split):
              - commit the carton that packs the most volume
              - return the leftovers to the pool, together with the not-yet-committed batches
        (optional) backfill: try the remaining items in the open carton's free space
   stop when the pool is empty, or a round packs nothing (the rest is flagged "unpackable")
```

**Fill cap (the "70% rule")** – orders with more than `bin_max_fill_check_min_item_qty` (default 6) items in a carton may fill only `bin_max_fill_pct` % of its usable volume (default 70). It is a **user-defined setting** and is applied in both stages through one function (`get_allowed_volume`), so changing it changes the planner and the 3D result consistently.

Usable height of a carton = height − `bin_buffer_h` (6 mm).

---

## Data

Input is a JSON list of orders:

```json
{
  "input": {
    "OrderId": 1, "OrderNo": "1",
    "Items": { "ItemsList": [
      { "Code": "63", "Length": 140, "Width": 80, "Height": 116.0, "Weight": 0.285,
        "UOM": "EA", "VerticalRotation": 1, "Quantity": 1 }
    ]},
    "Bins": { "BinsList": [ { "Code": "Box2", "Length": 270, "Width": 170, "Height": 115, "MaxWeight": 20 } ] },
    "OptimizationMode": "bins_number"
  }
}
```

`VerticalRotation = 0` means the item must stay upright (only its length/width may swap).

Cartons used (identical in every order of the sample; hard-coded as `DEFAULT_BOXES`, the per-order `Bins` field is currently ignored):

| Carton | Length | Width | Height | Max weight |
|---|---|---|---|---|
| Box2 | 270 | 170 | 115 | 20 |
| Box4 | 340 | 260 | 150 | 20 |
| Box5 | 340 | 260 | 235 | 20 |
| Box6 | 340 | 260 | 280 | 20 |
| Box8 | 290 | 180 | 280 | 20 |
| Box9 | 440 | 345 | 280 | 20 |

**Benchmark sample:** 2,000 orders, 8,031 SKU lines, 15,103 items after expanding quantities (mean 7.55 items per order, max 32). 1,102 SKU lines are upright-only. Only 6 of 2,000 orders weigh more than 20 kg in total, so weight is rarely the binding constraint.
The dataset is not included in this repository.

---

## Configuration (`Config`)

| Field | Default | Meaning |
|---|---|---|
| `bin_max_fill_pct` | `70.0` | Fill cap in % of usable volume. User-defined; must be in (0, 100]. |
| `bin_max_fill_check_min_item_qty` | `6` | The cap applies when a carton holds more items than this. |
| `bin_buffer_h` | `6.0` | Height buffer subtracted from every carton. |
| `orientation_mode` | `"tall_first"` | Order in which rotations are tried: `legacy`, `original_first`, `low_height`, `tall_first`. |
| `item_order` | `"multi"` | Order items are fed to the 3D engine: `volume`, `height`, or `multi` (tries volume / height / footprint / longest side, keeps the first that packs everything). |
| `ep_mode` | `"auto"` | Candidate placement points: `basic` (3 per item), `full` (all edge combinations), `auto` (`basic`, retried with `full` only on a forced split). |
| `backfill` | `False` | Try remaining items in an open carton's free space before closing it. |

Invalid values raise `ValueError`.

### Usage

```python
config = Config(bin_max_fill_pct=70.0)
result = solve_order_best_fit(order, DEFAULT_BOXES, config, return_layout=True)
# result: status, total_cartons, cartons_used, total_items, unpacked_items, average_fill_pct,
#         carton_volume, planner_status, planner_cartons, box_upgrades, forced_splits,
#         rounds, backfilled_items, runtime_ms, layout (x, y, z, l, w, h per item)

run_benchmark_and_print("data_samples_v2.json")   # summary + sweeps
```

`status` is `single_box_fit`, `multi_box_split`, `unpackable` (some items fit no carton), or `empty`.

---

## Version history

### Starting point – v1.4 review (fixed in v1.5)
Bugs found while reading the v1.4 notebook:
- The multi-box `while` loop had its commit/removal block outside the loop → infinite loop on any multi-carton order.
- `return True` inside the new-point loop (only 1 of 3 extreme points was ever generated) and `return False` inside the candidate-point loop (gave up after one point).
- Items were removed by their *rotated* dimensions, so rotated items were never removed.
- Candidate points were sorted by (y, z) instead of (z, y, x).
- An item that fits no carton produced a silent "0 cartons" result.

The first, second and third points and the sort order were fixed in the author's revision. **v1.5** fixed the item removal (now by object identity) and added the `unpackable` status.

### v1.6 – planner + 3D engine as one pipeline
- Volumetric planner rewritten: items that cannot fit even an empty largest carton are set aside (no infinite loop), and the best-fit carton uses the final batch size.
- Shared fill-cap function used by both stages.
- Pre-screening of items that cannot fit any empty carton.
- Feedback loop: the box search starts at the planner's assigned carton; forced splits commit a partial carton and re-plan the leftovers.
- Leftovers are re-planned **together with the not-yet-committed batches of the same order**. In a synthetic test set this cut the orders needing more cartons than a pure 3D greedy from 30 to 5 (at a 100 % cap).
- New metrics: planner vs 3D disagreement, box upgrades, forced splits, rounds; optional `return_layout`.

### v1.7 – orientation experiment
- Added `orientation_mode` and `compare_orientation_modes()`, plus the `carton_volume` metric (total usable volume of the cartons used), because carton count and fill % can hide a downsize.
- `tall_first` became the default. `legacy` reproduces v1.6 exactly.

### v1.8 – backfill, config validation
- Added the optional `backfill` step and `compare_backfill()`.
- `Config` now validates the user-defined fill cap and the mode names.
- Diagnostics: 51.7 % of orders only needed a bigger carton than the planner assigned; 9.6 % needed a forced split; only 29 orders ended with more cartons than the planner predicted. Dropping the 6 mm buffer to 0 would move only about 61 orders into Box2.

### v1.9 – stronger 3D engine
- `ep_mode`: `basic`, `full`, `auto`. The `full` engine matched a brute-force reference exactly on 600 test cartons.
- `item_order`: `volume`, `height`, `multi`.
- New comparison tools: `compare_engines()`, `compare_item_orders()`, `sweep_engine_modes()`.
- New defaults: `orientation_mode="tall_first"`, `item_order="multi"`, `ep_mode="auto"`. Backfill stays off.

---

## Results on the 2,000-order sample

### Baseline (v1.6, cap 70 %)
Single-box 89.15 %, multi-box 10.85 %, unpackable 0 %, 1.111 cartons per order, 44.84 % average fill, 0.19 ms average latency.

| Fill cap | Avg cartons | Avg fill % |
|---|---|---|
| 50 % | 1.162 | 40.19 |
| 60 % | 1.130 | 43.54 |
| 70 % | 1.110 | 44.84 |
| 80 % | 1.106 | 45.58 |
| 90 % / 100 % | 1.106 | 45.68 |

### Orientation (v1.7, cap 70 %; carton volume index: legacy = 100)

| Mode | Avg cartons | Avg fill % | Carton volume idx |
|---|---|---|---|
| legacy | 1.1105 | 44.84 | 100.0 |
| original_first | 1.1115 | 45.39 | 98.3 |
| low_height | 1.1215 | 44.25 | 102.2 |
| **tall_first** | 1.1105 | 46.00 | **97.0** |

`tall_first` was also better in each of four 500-order chunks (volume index 94.8 – 98.4).

### Backfill (v1.8)
Almost no effect: 1.1105 → 1.1100 cartons at a 70 % cap (1 order fewer), 1.1050 → 1.1045 at 100 %. A free-volume check suggested much more, but free volume is not usable space for the old placement engine.

### Item order × engine (v1.9; baseline = `basic` + `volume`)

| Cap | Setting | Avg cartons | Avg fill % | Carton volume idx | Orders fewer / more |
|---|---|---|---|---|---|
| 70 % | basic + multi | 1.1075 | 47.10 | 97.3 | 7 / 1 |
| 70 % | full + multi | 1.1075 | 46.73 | 97.0 | 7 / 1 |
| 100 % | basic + multi | 1.1015 | 47.37 | 96.9 | 7 / 0 |
| 100 % | full + volume | 1.1025 | 46.73 | 99.1 | 5 / 0 |
| 100 % | full + height | 1.0850 | 46.33 | 99.6 | 60 / 20 |
| 100 % | **full + multi** | **1.0725** | **48.15** | **95.7** | **65 / 0** |

Candidate points alone help little; they pay off together with a better item order (tallest-first builds flat layers, and most items are 100 – 125 mm tall).

### Engine mode vs fill cap (`item_order="multi"`)

| Cap | basic cartons | full / auto cartons | Orders fewer | Avg latency basic / full / auto |
|---|---|---|---|---|
| ≤ 70 % | 1.1075 | 1.1075 | 0 | auto ≈ +10 % vs basic |
| 75 % | 1.1035 | 1.0750 | 57 | 0.48 / 1.28 / 0.60 ms |
| 80 – 95 % | 1.1015 – 1.1020 | 1.0730 | 57 – 58 | auto 0.50 – 0.91 ms |
| 100 % | 1.1015 | 1.0725 | 58 | 0.57 / 1.57 / 0.94 ms |

No order got more cartons in any mode. `auto` keeps the carton savings of `full` at roughly half its latency cost.

### Final default configuration (cap 70 %)
Single-box 89.50 %, multi-box 10.50 %, unpackable 0 %, 1.107 cartons per order, 47.10 % fill, 0.37 ms average and 0.96 ms P95 latency.

---

## Validation

Checked on all 2,000 orders for every engine / order / cap / backfill combination listed above, with **zero violations**:
no overlapping items, every item inside the carton (including the 6 mm buffer), carton weight ≤ max weight, fill cap respected, upright-only items keep their height, and every item is either placed or reported as unpacked.
These checks were run as scripts and are not yet part of the repository as automated tests.

---

## Observations about the sample

- About 74 orders have a total item volume between 70 % and 75 % of Box9's usable volume; 65 orders have exactly 71.1 %. This is why the gain appears abruptly between a 70 % and a 75 % cap. Check whether this cluster is real before tuning the default cap to this sample.
- The planner is a good but optimistic filter: it says "fits" more often than the 3D engine confirms, which costs a larger carton rather than an extra carton in most cases.

## Known limitations

- **No support / gravity check.** Items can rest partly or fully on empty space. Measured with the default settings: 3 – 6 % of placed items are not fully supported, 0.3 – 0.6 % are less than 50 % supported, and 16 – 19 % of orders contain at least one such item. Carton counts are therefore somewhat optimistic.
- Results come from one 2,000-order sample and have not been compared with real packing outcomes.
- Items with missing or zero dimensions get volume 0 and pack silently.
- Only `OptimizationMode = "bins_number"` is handled; the per-order `Bins` list is ignored.
- The planner's multi-carton split is greedy, not optimal.
- Pure Python: about 1 ms per order on average, but up to roughly 5 ms P95 at high caps with `full` / `auto`.

## Next steps

1. Add a minimum-support (gravity) constraint to the 3D engine, as a user-settable parameter, and re-run all experiments.
2. Validate on a real hold-out set and against the cartons actually used.
3. Harden the input handling (missing dimensions, per-order bins, other optimisation modes).
4. Turn the validation scripts into automated tests and move the code from the notebooks into a module.
5. Re-measure backfill with the new engine.

## Files

| File | Content |
|---|---|
| `capstone1_6.ipynb` | Unified planner + 3D pipeline |
| `capstone1_7.ipynb` | Orientation modes, `carton_volume` metric |
| `capstone1_8.ipynb` | Backfill, config validation |
| `capstone1_9.ipynb` | `ep_mode`, `item_order`, engine sweeps, new defaults |

Notebook cell order: imports → data classes + `Config` + `DEFAULT_BOXES` → volumetric planner → 3D engine → unified pipeline → benchmark and experiments.
